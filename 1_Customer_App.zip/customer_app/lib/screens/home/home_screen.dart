import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../utils/app_theme.dart';
import '../../utils/app_router.dart';
import '../../models/restaurant_model.dart';
import '../../widgets/restaurant_card.dart';
import '../../widgets/category_chip.dart';
import '../../widgets/offer_banner.dart';
import '../../widgets/shimmer_loader.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _selectedCategory = 'All';
  final _searchCtrl = TextEditingController();
  String _search = '';

  final _categories = ['All', 'Pizza', 'Burger', 'Chowmin', 'Biryani', 'Snacks', 'Desserts'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            pinned: true,
            backgroundColor: Colors.white,
            expandedHeight: 56,
            toolbarHeight: 56,
            title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Deliver to', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              Row(children: const [
                Text('Home', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                SizedBox(width: 4),
                Icon(Icons.keyboard_arrow_down_rounded, size: 20, color: AppColors.primary),
              ]),
            ]),
            actions: [
              IconButton(
                onPressed: () {},
                icon: Stack(children: [
                  const Icon(Icons.notifications_outlined, color: AppColors.textPrimary),
                  Positioned(right: 0, top: 0, child: Container(
                    width: 8, height: 8,
                    decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                  )),
                ]),
              ),
              const SizedBox(width: 8),
            ],
          ),
        ],
        body: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () async => setState(() {}),
          child: CustomScrollView(slivers: [
            SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Search
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: TextField(
                  controller: _searchCtrl,
                  onChanged: (v) => setState(() => _search = v.toLowerCase()),
                  decoration: InputDecoration(
                    hintText: 'Search for restaurants or food...',
                    prefixIcon: const Icon(Icons.search, color: AppColors.textHint),
                    suffixIcon: _search.isNotEmpty
                        ? IconButton(icon: const Icon(Icons.clear, size: 18), onPressed: () { _searchCtrl.clear(); setState(() => _search = ''); })
                        : null,
                  ),
                ),
              ),
              // Offers banner
              const SizedBox(height: 16),
              SizedBox(height: 140, child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: 3,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, i) => OfferBanner(index: i),
              )),
              // Categories
              const SizedBox(height: 16),
              SizedBox(height: 36, child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => CategoryChip(
                  label: _categories[i],
                  selected: _selectedCategory == _categories[i],
                  onTap: () => setState(() => _selectedCategory = _categories[i]),
                ),
              )),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text('Restaurants near you', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
              ),
              const SizedBox(height: 8),
            ])),
            // Restaurant list
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('restaurants').where('isOpen', isEqualTo: true).snapshots(),
              builder: (ctx, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return SliverList(delegate: SliverChildBuilderDelegate((_, i) => const ShimmerCard(), childCount: 4));
                }
                var docs = snap.data?.docs ?? [];
                var restaurants = docs.map((d) => Restaurant.fromMap(d.data() as Map<String, dynamic>, d.id)).toList();
                if (_selectedCategory != 'All') {
                  restaurants = restaurants.where((r) => r.cuisineType.toLowerCase().contains(_selectedCategory.toLowerCase())).toList();
                }
                if (_search.isNotEmpty) {
                  restaurants = restaurants.where((r) => r.name.toLowerCase().contains(_search) || r.cuisineType.toLowerCase().contains(_search)).toList();
                }
                if (restaurants.isEmpty) {
                  return const SliverToBoxAdapter(child: Center(child: Padding(padding: EdgeInsets.all(40), child: Text('No restaurants found', style: TextStyle(color: AppColors.textSecondary)))));
                }
                return SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  sliver: SliverList(delegate: SliverChildBuilderDelegate(
                    (_, i) => RestaurantCard(restaurant: restaurants[i]),
                    childCount: restaurants.length,
                  )),
                );
              },
            ),
          ]),
        ),
      ),
    );
  }
}
